
import 'package:flutter/material.dart';
import 'dashboard.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class Login extends StatefulWidget{
 @override _LoginState createState()=>_LoginState();
}

class _LoginState extends State<Login>{
 var u=TextEditingController();
 var p=TextEditingController();

 login() async{
  var r=await http.post(Uri.parse("http://YOUR_IP/api/login.php"),
   headers:{"Content-Type":"application/json"},
   body:jsonEncode({"username":u.text,"password":p.text}));
  var d=jsonDecode(r.body);
  if(d["status"]=="success"){
    Navigator.push(context,MaterialPageRoute(builder:(_)=>Dashboard(d["token"])));
  }
 }

 @override
 Widget build(context){
  return Scaffold(
   body:Center(
    child:Column(mainAxisSize:MainAxisSize.min,children:[
      Text("Login",style:TextStyle(fontSize:24)),
      TextField(controller:u,decoration:InputDecoration(labelText:"Username")),
      TextField(controller:p,decoration:InputDecoration(labelText:"Password")),
      ElevatedButton(onPressed:login, child:Text("Login"))
    ])
   )
  );
 }
}
