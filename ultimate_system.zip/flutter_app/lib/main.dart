
import 'package:flutter/material.dart';
import 'login.dart';

void main()=>runApp(MyApp());

class MyApp extends StatelessWidget{
 @override
 Widget build(context){
  return MaterialApp(
   debugShowCheckedModeBanner:false,
   theme:ThemeData(primaryColor:Color(0xFF1E2A38)),
   home:Login()
  );
 }
}
