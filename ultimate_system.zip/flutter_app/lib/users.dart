
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class Users extends StatefulWidget{
 final String token;
 Users(this.token);

 @override _UsersState createState()=>_UsersState();
}

class _UsersState extends State<Users>{
 List users=[];

 fetch() async{
  var r=await http.get(Uri.parse("http://YOUR_IP/api/get_users.php"),
   headers:{"Authorization":widget.token});
  setState(()=>users=jsonDecode(r.body));
 }

 @override void initState(){super.initState();fetch();}

 @override
 Widget build(context){
  return ListView.builder(
   itemCount:users.length,
   itemBuilder:(c,i)=>Card(
    child:ListTile(title:Text(users[i]['username']))
   )
  );
 }
}
