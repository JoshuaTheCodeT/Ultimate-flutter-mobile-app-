
import 'package:flutter/material.dart';
import 'users.dart';

class Dashboard extends StatefulWidget{
 final String token;
 Dashboard(this.token);

 @override _DashboardState createState()=>_DashboardState();
}

class _DashboardState extends State<Dashboard>{
 int index=0;

 @override
 Widget build(context){
  return Scaffold(
   appBar:AppBar(title:Text("Ultimate Dashboard")),
   drawer:Drawer(
    child:ListView(children:[
      ListTile(title:Text("Users"),onTap:()=>setState(()=>index=0))
    ])
   ),
   body:index==0?Users(widget.token):Container()
  );
 }
}
