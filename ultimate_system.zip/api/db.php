
<?php
$conn = new mysqli("localhost", "root", "", "your_database");
if ($conn->connect_error) die("DB Error");
?>
