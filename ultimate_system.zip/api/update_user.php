
<?php
include "db.php";
$d=json_decode(file_get_contents("php://input"));
$stmt=$conn->prepare("UPDATE users SET username=? WHERE id=?");
$stmt->bind_param("si",$d->username,$d->id);
echo json_encode(["status"=>$stmt->execute()]);
?>
