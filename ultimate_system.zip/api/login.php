
<?php
include "db.php";
$d=json_decode(file_get_contents("php://input"));
$stmt=$conn->prepare("SELECT * FROM users WHERE username=?");
$stmt->bind_param("s",$d->username);
$stmt->execute();
$r=$stmt->get_result();
if($u=$r->fetch_assoc()){
 if(password_verify($d->password,$u['password'])){
  $token=bin2hex(random_bytes(16));
  $conn->query("UPDATE users SET token='$token' WHERE id=".$u['id']);
  echo json_encode(["status"=>"success","token"=>$token,"user"=>$u]);
 } else echo json_encode(["status"=>"error"]);
} else echo json_encode(["status"=>"error"]);
?>
